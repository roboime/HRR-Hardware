designFile = "D:/sampaio/Desktop/RoboIME/HRR-Hardware/PDNAnalyzer_Output/PCB/odb.tgz"

powerNets = ["VBAT", "5V1", "5V2"]

groundNets = ["GND"]

excitation = [
{
"id": "0",
"type": "source",
"power_pins": [ ("Q1", "11"), ("Q1", "10"), ("Q1", "9"), ("Q1", "8"), ("Q1", "7"), ("Q1", "6"), ("Q1", "5") ],
"ground_pins": [ ("BATTERY_CONNECTOR", "1") ],
"voltage": 12,
"Rpin": 0,
}
,
{
"id": "1",
"type": "load",
"power_pins": [ ("J1_MOUT1", "2") ],
"ground_pins": [ ("J1_MOUT1", "1") ],
"current": 1.5,
"Rpin": 0.0666666666666667,
}
,
{
"id": "2",
"type": "load",
"power_pins": [ ("J1_MOUT2", "2") ],
"ground_pins": [ ("J1_MOUT2", "1") ],
"current": 1.5,
"Rpin": 0.0666666666666667,
}
,
{
"id": "3",
"type": "load",
"power_pins": [ ("J1_MOUT3", "2") ],
"ground_pins": [ ("J1_MOUT3", "1") ],
"current": 1.5,
"Rpin": 0.0666666666666667,
}
,
{
"id": "4",
"type": "load",
"power_pins": [ ("J1_MOUT4", "2") ],
"ground_pins": [ ("J1_MOUT4", "1") ],
"current": 1.5,
"Rpin": 0.0666666666666667,
}
,
{
"id": "5",
"type": "load",
"power_pins": [ ("J1_MOUT5", "2") ],
"ground_pins": [ ("J1_MOUT5", "1") ],
"current": 1.5,
"Rpin": 0.0666666666666667,
}
,
{
"id": "6",
"type": "load",
"power_pins": [ ("J1_MOUT6", "2") ],
"ground_pins": [ ("J1_MOUT6", "1") ],
"current": 1.5,
"Rpin": 0.0666666666666667,
}
,
{
"id": "7",
"type": "load",
"power_pins": [ ("J1_MOUT7", "2") ],
"ground_pins": [ ("J1_MOUT7", "1") ],
"current": 1.5,
"Rpin": 0.0666666666666667,
}
,
{
"id": "8",
"type": "load",
"power_pins": [ ("J1_MOUT8", "2") ],
"ground_pins": [ ("J1_MOUT8", "1") ],
"current": 1.5,
"Rpin": 0.0666666666666667,
}
,
{
"id": "9",
"type": "load",
"power_pins": [ ("J1_MOUT9", "2") ],
"ground_pins": [ ("J1_MOUT9", "1") ],
"current": 1.5,
"Rpin": 0.0666666666666667,
}
,
{
"id": "10",
"type": "load",
"power_pins": [ ("J1_MOUT10", "2") ],
"ground_pins": [ ("J1_MOUT10", "1") ],
"current": 1.5,
"Rpin": 0.0666666666666667,
}
,
{
"id": "11",
"type": "load",
"power_pins": [ ("J1_MOUT11", "2") ],
"ground_pins": [ ("J1_MOUT11", "1") ],
"current": 1.5,
"Rpin": 0.0666666666666667,
}
,
{
"id": "12",
"type": "load",
"power_pins": [ ("J1_MOUT12", "2") ],
"ground_pins": [ ("J1_MOUT12", "1") ],
"current": 1.5,
"Rpin": 0.0666666666666667,
}
,
{
"id": "13",
"type": "load",
"power_pins": [ ("U3_U_5v1", "1") ],
"ground_pins": [ ("U3_U_5v1", "4"), ("U3_U_5v1", "8") ],
"current": 2.5,
"Rpin": 0.0533333333333333,
}
,
{
"id": "14",
"type": "load",
"power_pins": [ ("U3_U_5v2", "1") ],
"ground_pins": [ ("U3_U_5v2", "8"), ("U3_U_5v2", "4") ],
"current": 2.5,
"Rpin": 0.0533333333333333,
}
,
{
"id": "15",
"type": "source",
"power_pins": [ ("U3_U_5v1", "7") ],
"ground_pins": [ ("U3_U_5v1", "4"), ("U3_U_5v1", "8") ],
"voltage": 5,
"Rpin": 0,
}
,
{
"id": "16",
"type": "load",
"power_pins": [ ("J2", "2"), ("J2", "4") ],
"ground_pins": [ ("J2", "6"), ("J2", "9"), ("J2", "14"), ("J2", "20"), ("J2", "25"), ("J2", "30"), ("J2", "34"), ("J2", "39") ],
"current": 2.5,
"Rpin": 0.128,
}
,
{
"id": "17",
"type": "load",
"power_pins": [ ("P7", "1") ],
"ground_pins": [ ("P7", "2") ],
"current": 0.5,
"Rpin": 0.2,
}
,
{
"id": "18",
"type": "source",
"power_pins": [ ("U3_U_5v2", "7") ],
"ground_pins": [ ("U3_U_5v2", "8"), ("U3_U_5v2", "4") ],
"voltage": 5,
"Rpin": 0,
}
,
{
"id": "19",
"type": "load",
"power_pins": [ ("P4_9GOUT1", "2") ],
"ground_pins": [ ("P4_9GOUT1", "3") ],
"current": 0.65,
"Rpin": 0.153846153846154,
}
,
{
"id": "20",
"type": "load",
"power_pins": [ ("P4_9GOUT2", "2") ],
"ground_pins": [ ("P4_9GOUT2", "3") ],
"current": 0.65,
"Rpin": 0.153846153846154,
}
,
{
"id": "21",
"type": "load",
"power_pins": [ ("P4_9GOUT3", "2") ],
"ground_pins": [ ("P4_9GOUT3", "3") ],
"current": 0.65,
"Rpin": 0.153846153846154,
}
,
{
"id": "22",
"type": "load",
"power_pins": [ ("P4_9GOUT4", "2") ],
"ground_pins": [ ("P4_9GOUT4", "3") ],
"current": 0.65,
"Rpin": 0.153846153846154,
}
,
{
"id": "23",
"type": "load",
"power_pins": [ ("P4_9GOUT5", "2") ],
"ground_pins": [ ("P4_9GOUT5", "3") ],
"current": 0.65,
"Rpin": 0.153846153846154,
}
,
{
"id": "24",
"type": "load",
"power_pins": [ ("P4_9GOUT6", "2") ],
"ground_pins": [ ("P4_9GOUT6", "3") ],
"current": 0.65,
"Rpin": 0.153846153846154,
}
]


voltage_regulators = []


# Resistors / Inductors

passives = []


# Material Properties:

tech = [

        {'name': 'TOP_SOLDER', 'DielectricConstant': 3.5, 'Thickness': 1.016E-05},
        {'name': 'TOP_LAYER', 'Conductivity': 47000000, 'Thickness': 3.5E-05},
        {'name': 'SUBSTRATE-1', 'DielectricConstant': 4.8, 'Thickness': 0.0016},
        {'name': 'BOTTOM_LAYER', 'Conductivity': 47000000, 'Thickness': 3.5E-05},
        {'name': 'BOTTOM_SOLDER', 'DielectricConstant': 3.5, 'Thickness': 1.016E-05}

       ]

special_settings = {'removecutoutsize' : 7.8 }


plating_thickness = 0.7
finished_hole_diameters = False
